﻿$.fn.extend({
    mDataTable: function (data) {
        var $table = $(this);
        $table.children("tbody").empty();
        var url = data.ajax;
        var columns = data.columns;
        var $tbody = $("<tbody></tbody>");
        $.post(url, function (res) {
            if (res.code == 0) {
                $.each(res.res, function (i, e) {
                    var $tr = $('<tr></tr>');
                    for (var i = 0; i < columns.length; i++) {
                        var column = columns[i];
                        var render = column.render;
                        var className = column.class;
                        var $td = $("<td></td>");
                        if (render != undefined) {
                            $td.append(render(e[column.data], e));
                        } else {
                            $td.html(e[column.data]);
                        }
                        if (column.hidden) {
                            $td.addClass("hidden");
                        }
                        if (className != undefined) {
                            $td.addClass(className);
                        }
                        $tr.append($td);
                        $tbody.append($tr);
                    }
                })
            }
            else {

            }
            $table.append($tbody);
        });
    }
});
